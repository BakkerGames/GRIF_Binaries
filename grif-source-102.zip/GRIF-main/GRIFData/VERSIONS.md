# Versions

1.0.0 - Initial Version

1.0.1 - ReadMe clarification

1.0.2 - ReadMe typo fixed

1.1.0 - Updated GROD and DAGS

1.1.2 - Updated DAGS

1.1.4 - Don't run PrettyScript when there are script errors

1.2.0 - Switched from System.Text.Json to specialized routines for more flexibility

1.2.1 - Skip comments as whitespace - /* */ and // to eol

1.3.0 - Added LoadDataFromString, SaveDataToString, SaveOverlayDataToString for non-file processing.