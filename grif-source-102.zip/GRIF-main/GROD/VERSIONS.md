# Versions

1.0.0 - Initial Version.

1.0.1 - Explicitly handle null

1.0.2 - Clear=both, add ClearBase, more tests

1.0.3 - Fixed

1.0.4 - Better prefix handling

1.0.5 - Removed prefixes, calling program will handle

1.0.6 - Comments

1.1.0 - Renamed to GROD

1.1.1 - Added Added ReadMe() and VersionHistory() for retriving that information.

1.1.2 - Null check on resource stream